//
//  ViewController.swift
//  Security
//
//  Created by Antonio Adrian Chavez on 10/31/18.
//  Copyright © 2018 Antonio Adrian Chavez. All rights reserved.
//

import UIKit
import LocalAuthentication

class ViewController: UIViewController {
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
    }

    override func didReceiveMemoryWarning()
    {
       super.didReceiveMemoryWarning()
        //Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func Passcode(_ sender: Any) {
        
        
    }
    
    
    @IBAction func TouchID(_ sender: Any)
    {
        let context: LAContext = LAContext()
        
        if context.canEvaluatePolicy(LAPolicy.deviceOwnerAuthentication, error: nil)
        {
            context.evaluatePolicy(LAPolicy.deviceOwnerAuthentication, localizedReason: "Log in with fingerprint", reply: { (wasCorrect, error) in
                if wasCorrect
                {
                    print("Correct")
                }
                else
                {
                    print("Incorrect")
                }
                
            })
        }
        else
        {
            //alart that said it don't support Touch ID.
        }
        
        }
    
    @IBAction func FaceID(_ sender: Any) {
        let context: LAContext = LAContext()
        
        let reason = "Log in with Face ID"
        context.evaluatePolicy(LAPolicy.deviceOwnerAuthenticationWithBiometrics, localizedReason: reason, reply: { (wasCorrect, error) in
            if wasCorrect
            {
                print("Correct")
            }
            else
            {
                print("Incorrect")
            }
            
        })
        
        
    }
}
